TW.Runtime.Widgets.test_widget= function () {
	var valueElem;
	const thisWidget = this;
	this.renderHtml = function () {
		// return any HTML you want rendered for your widget
		// If you want it to change depending on properties that the user
		// has set, you can use this.getProperty(propertyName). In
		// this example, we'll just return static HTML
		return 	'<div class="widget-content widget-test_widget"><span class="widget-test_widget-span"></span></div>';
	};
	
	this.afterRender = function () {
		
	};

	// this is called on your widget anytime bound data changes
	this.updateProperty = function (updatePropertyInfo) {
	};
	
	this.getPropertyValues = (thingname, category) => {
		const invoker = new ThingworxInvoker({ 
		    entityType: 'Things',
		    entityName: thingname,
		    characteristic: 'Services',
		    target: 'getValues',
		    apiMethod: 'POST',
		    parameters: {
		    	category
		    }
		});
		const success = function (invoker) {
			const dataFromInvoke = invoker.result;
		     console.log(dataFromInvoke);
		     TW.Runtime.showStatusText('testmessage', JSON.stringify(dataFromInvoke)); 
		     thisWidget.jqElement.find(".widget-test_widget-span").text(JSON.stringify(dataFromInvoke));
		};
		const fail = function (invoker, xhr) {
		    TW.log.error('GetComments failed');
		    TW.Runtime.showStatusText('error', 'Error"' + xhr.responseText + '"');
		};		
		
		invoker.invokeService(success, fail);
	}
	
	this.serviceInvoked = function (serviceName) {
		if(serviceName === "render") {
			console.log(this.getProperty("thingname") + ", " + this.getProperty("category"));
			this.getPropertyValues(this.getProperty("thingname"), this.getProperty("category"));
		}
    };
};