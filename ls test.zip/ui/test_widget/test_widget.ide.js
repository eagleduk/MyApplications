TW.IDE.Widgets.test_widget = function () {

	this.widgetIconUrl = function() {
		return  "'../Common/extensions/ls test/ui/test_widget/default_widget_icon.ide.png'";
	};

	this.widgetProperties = function () {
		return {
			'name': 'test widget',
			'description': '',
			'category': ['Common'],
			'properties': {
				'thingname': {
					'baseType': 'THINGNAME',
					'isBindingTarget': true
				},
				'category': {
					'baseType': 'STRING',
					'defaultValue': 'property category'
				}
			}
		}
	};

	this.afterSetProperty = function (name, value) {
		var thisWidget = this;
		var refreshHtml = false;
		switch (name) {
			case 'Style':
			case 'test widget Property':
				thisWidget.jqElement.find('.test-widget-property').text(value);
			case 'Alignment':
				refreshHtml = true;
				break;
			default:
				break;
		}
		return refreshHtml;
	};
	
	this.widgetServices = function () {
        return {
            'render': {},
        };
    };

	this.renderHtml = function () {
		// return any HTML you want rendered for your widget
		// If you want it to change depending on properties that the user
		// has set, you can use this.getProperty(propertyName).
		return 	'<div class="widget-content widget-test_widget">' +
					'<span class="test-widget-property">' + this.getProperty('test widget Property') + '</span>' +
				'</div>';
	};

	this.afterRender = function () {
		// NOTE: this.jqElement is the jquery reference to your html dom element
		// 		 that was returned in renderHtml()

		// get a reference to the value element
		valueElem = this.jqElement.find('.test-widget-property');
		// update that DOM element based on the property value that the user set
		// in the mashup builder
		valueElem.text(this.getProperty('test widget Property'));
	};

};